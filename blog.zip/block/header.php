<header>  
    <?php 
    require_once "block/head.php";
    ?>
            <div id ="logo">
               <a href="Index.php"><span>Н</span>овости</a>
            </div>
            <div id="menu">
                <a href="about.php">
                    <div style="margin-right: 15%">О нас</div>
                </a> 
                <a href="feedback.php">
                    <div> Обратная связь </div>
                </a>
            </div>
                <a href="#modalWindow" class = "button">Регистрация | Авторизация</a>
                <div id="modalWindow">
                    <div class="windowi">
                        <p>Вход</p>
                    </div>
                    <a href="#close" class="close">x</a>
                </div>
          
            
</header>