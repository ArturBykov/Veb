<footer>
    <div id="social">
        <a href="http://vk.com" title="Vk" target="_blank">
            <img src="img/vk.png" alt="Vk" title="Vk">
        </a>
    </div>
        <div id="right">
            Все права защищеный &copy; 
            <?=date ('Y'); ?>
        </div>
</footer>