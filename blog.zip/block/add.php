<div id="rightCol">
    <div class="banner">
        <img src="img/baner1.jpg" alt="Baner" title="Baner">
    </div>
    <div class="banner">
        <img src="img/baner2.jpg" alt="Baner" title="Baner">
    </div>
                
</div>