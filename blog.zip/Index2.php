<!DOCTYPE html>
<html>
    <head>
        <?php 
            $title = "feedback";
            require_once "block/head.php";
        ?>
    </head>
    
    <body>
        
        
        
        <?php require_once "block/header.php";?>
        
        <div id="wrapper">
            <div id="leftCol">
                <div id="alltext">
                <p>djfdklgnkjdfng dfkjg ndfkjgbndkjbn dfkjn dfkjnb dfkjlbndfkjlnbkjdn 
                 fgn dfkbndfkbn dfklm bdfklmbdfklm b
                 vdfknl dfkj kldfmb ;dfb ldfmbkj nkjb dsljps
                 dfs]b jdfs;lk dfbk;ldfsbklmfk;lbdfsbld
                 dfsbj;dsnb;ldffdfkjg kdfgkjdfnijdfhbkjnkj bdfjbn kjdfnbkjldfljbkjldfbhjdfnkjl</p>
                </div>
            </div>
            
             <?php require_once "block/add.php"; ?>
        </div>
        
    </body>
    
     <?php require_once "block/footer.php"; ?>
</html>